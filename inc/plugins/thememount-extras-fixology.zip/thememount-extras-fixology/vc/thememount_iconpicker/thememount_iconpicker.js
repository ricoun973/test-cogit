
// This function is available in admin-custom.js file. This function is also used in CodeStar icon picker developed by ThemeMount
thememount_icon_picker();

/*
if( jQuery('.thememount-iconpicker-wrapper').length > 0 ){
	jQuery('.thememount-iconpicker-wrapper').each(function(){
		var wrapper = jQuery(this);
		jQuery('.thememount-iconpicker-list', wrapper ).iconpicker({
			align: 'left', // Only in div tag
			//arrowClass: 'btn-danger',
			arrowPrevIconClass: 'fa fa-chevron-left',
			arrowNextIconClass: 'fa fa-chevron-right',
			cols: 8,
			//footer: true,
			//header: true,
			icon: jQuery(this).data('icon'),
			iconset: jQuery(this).data('iconset'),
			//labelHeader: '{0} of {1} pages',
			//labelFooter: '{0} - {1} of {2} icons',
			//placement: 'bottom', // Only in button tag
			rows: 5,
			//search: true,
			//searchText: 'Search',
			//selectedClass: 'btn-success',
			//unselectedClass: ''
		});

		jQuery('.thememount-iconpicker-list', wrapper ).on('change', function(e) {
			jQuery('.tm-ipicker-selected-icon i',wrapper).removeClass().addClass( e.icon );
			jQuery('.thememount-iconpicker-input',wrapper).val(e.icon);
		});
	});
}



jQuery('.tm-ipicker-selector-w').each(function(){
	var $wrapper = jQuery(this);
	jQuery( '.tm-ipicker-selector-button', $wrapper ).click(function(){
		var $btn = jQuery(this);
		if( jQuery( '.thememount-iconpicker-list-w', $wrapper ).css('display')=='none' ){
			jQuery( '.thememount-iconpicker-list-w', $wrapper ).slideDown();
			jQuery( '.tm-ipicker-selector-button i', $wrapper ).removeClass('fa-arrow-down').addClass('fa-arrow-up');
		} else {
			jQuery( '.thememount-iconpicker-list-w', $wrapper ).slideUp();
			jQuery( '.tm-ipicker-selector-button i', $wrapper ).removeClass('fa-arrow-up').addClass('fa-arrow-down');
		}
		return false;
	});
	
	
	// Close icon picker on click outside
	jQuery(document).click(function(event) { 
		if(!jQuery(event.target).closest('.thememount-iconpicker-list-w', $wrapper).length) {
			if(jQuery('.thememount-iconpicker-list-w', $wrapper).is(":visible")) {
				//jQuery('.thememount-iconpicker-list-w', $wrapper).slideUp();
				jQuery( '.tm-ipicker-selector-button', $wrapper ).trigger('click');
			}
		}
	})
	
});
*/
