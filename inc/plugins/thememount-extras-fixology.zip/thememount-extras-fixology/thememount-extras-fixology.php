<?php
/*
 * Plugin Name: ThemeMount Extras for Fixology Theme
 * Plugin URI: http://www.thememount.com
 * Description: ThemeMount Plugin for Fixology Theme
 * Version: 1.0
 * Author: ThemeMount
 * Author URI: http://www.thememount.com
 * Text Domain: tmte
 * Domain Path: /languages
 */

/**
 *  TMTE = ThemeMount Theme Extras
 */
define( 'TMTE_VERSION', '1.0' );
define( 'TMTE_DIR', trailingslashit( dirname( __FILE__ ) ) );
define( 'TMTE_URI', plugins_url( '', __FILE__ ) );



/**
 *  Translation
 */
/*function tmte_load_plugin_textdomain() {
	$domain = 'thememount-extras-remould';
	$locale = apply_filters( 'plugin_locale', get_locale(), $domain );
	if ( $loaded = load_textdomain( 'tmte', trailingslashit( WP_LANG_DIR ) . $domain . '/' . $domain . '-' . $locale . '.mo' ) ) {
		return $loaded;
	} else {
		load_plugin_textdomain( 'tmte', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
	}
}
add_action( 'init', 'tmte_load_plugin_textdomain' );
*/




/**
 *  Codestar Framework core files
 */
function tmte_fixology_cs_framework_init(){
	defined('CS_OPTION'          ) or define('CS_OPTION',           'fixology');
	defined('CS_ACTIVE_FRAMEWORK') or define('CS_ACTIVE_FRAMEWORK', true    ); // default true
	defined('CS_ACTIVE_METABOX'  ) or define('CS_ACTIVE_METABOX',   true    ); // default true
	defined('CS_ACTIVE_SHORTCODE') or define('CS_ACTIVE_SHORTCODE', true    ); // default true
	defined('CS_ACTIVE_CUSTOMIZE') or define('CS_ACTIVE_CUSTOMIZE', true    ); // default true
	
	// Make shortcode work in text widget
	//add_filter('widget_text', 'do_shortcode');
	add_filter('widget_text', 'do_shortcode', 11);
	
}
add_action( 'init', 'tmte_fixology_cs_framework_init', 2 );




/**
 *  Codestar Framework core files
 */
function tmte_header_css(){
	echo '
<style>
th#thememount_featured_image, td.thememount_featured_image {
    width: 115px !important;
}
td.thememount_featured_image img{
    max-width: 75px;
	height: auto;
}
</style>
';
}
add_action( 'admin_head', 'tmte_header_css' );






add_action( 'plugins_loaded', 'tmte_remould_load_textdomain' );
/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 */
function tmte_remould_load_textdomain() {
	load_plugin_textdomain( 'tmte', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
}




/**
 *  Custom Post Types - With Post Meta Boxes
 */
if( function_exists('vc_map') ){
	require_once TMTE_DIR . 'vc/thememount_iconpicker/thememount_iconpicker.php';
}
if( file_exists( get_template_directory() . '/inc/tools.php' ) ){
	require_once get_template_directory() . '/inc/tools.php';
} else {
	require_once TMTE_DIR . 'tools.php';
}
require_once TMTE_DIR . 'custom-post-types/tm-portfolio.php';
require_once TMTE_DIR . 'custom-post-types/tm-team.php';
require_once TMTE_DIR . 'custom-post-types/tm-testimonial.php';
require_once TMTE_DIR . 'custom-post-types/tm-client.php';




/**
 *  Shortcodes
 */
require_once TMTE_DIR . 'shortcodes.php';



function tmte_rewrite_flush() {
    // ATTENTION: This is *only* done during plugin activation hook
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'tmte_rewrite_flush' );




/**
 * Enqueue scripts and styles
 */
if( !function_exists('tmte_fixology_scripts_styles') ){
function tmte_fixology_scripts_styles() {
	wp_enqueue_script( 'jquery-resize', TMTE_URI . '/js/jquery-resize.min.js', array( 'jquery' ) );
}
}
add_action( 'wp_enqueue_scripts', 'tmte_fixology_scripts_styles' );




/**
 * @param $param_value
 * @param string $prefix
 *
 * @since 4.2
 * @return string
 */
if( !function_exists('tm_vc_shortcode_custom_css_class') ){
function tm_vc_shortcode_custom_css_class( $param_value, $prefix = '' ) {
	$css_class = preg_match( '/\s*\.([^\{]+)\s*\{\s*([^\}]+)\s*\}\s*/', $param_value ) ? $prefix . preg_replace( '/\s*\.([^\{]+)\s*\{\s*([^\}]+)\s*\}\s*/', '$1', $param_value ) : '';
	return $css_class;
}
}


/**
 *  This function will do encoding things. The encode function is not allowed in theme so we created function in plugin
 */
if( !function_exists('thememount_enc_data') ){
function thememount_enc_data( $htmldata='' ) {
	return base64_encode($htmldata);
}
}



/************** Start Plugin Options settings ************************/




/**
 *  This will create option link and option page
 */
if( !function_exists('tmte_fixology_register_options_page') ){
function tmte_fixology_register_options_page() {
	add_options_page(
		esc_html__('Fixology Extra Options', 'tmte'),  // Page title in TITLE tag
		esc_html__('Fixology Extra Options', 'tmte'),  // heading on page
		'manage_options',
		'tmte-fixology',
		'tmte_fixology_options_page'
	);
}
}
add_action('admin_menu', 'tmte_fixology_register_options_page');


/**
 *  Save plugin options
 */
if( !function_exists('tmte_fixology_register_settings') ){
function tmte_fixology_register_settings() {
	
	// Social share for Blog
	register_setting( 'tmte_fixology_options_group', 'tmte_fixology_social_share_blog', 'tmte_fixology_social_share_blog_callback' );
	//add_option( 'tmte_fixology_option_name', 'This is my option value.');
	
	// Social share for Portfolio
	register_setting( 'tmte_fixology_options_group', 'tmte_fixology_social_share_portfolio', 'tmte_fixology_social_share_portfolio_callback' );
	//add_option( 'tmte_fixology_option_name', 'This is my option value.');
	

}
}
add_action( 'admin_init', 'tmte_fixology_register_settings' );




if( !function_exists('tmte_fixology_social_share_blog_callback') ){
function tmte_fixology_social_share_blog_callback( $data ){
	// Save settings to theme options so we can re-use it
	$fixology_toptions = get_option('fixology_theme_options');
	if( !empty($fixology_toptions['post_social_share_services']) ){
		$fixology_toptions['post_social_share_services'] = $data;
		update_option('fixology_theme_options', $fixology_toptions);
	}
	return $data;
}
}



if( !function_exists('tmte_fixology_social_share_portfolio_callback') ){
function tmte_fixology_social_share_portfolio_callback( $data ){
	// Save settings to theme options so we can re-use it
	$fixology_toptions = get_option('fixology_theme_options');
	if( !empty($fixology_toptions['portfolio_social_share_services']) ){
		$fixology_toptions['portfolio_social_share_services'] = $data;
		update_option('fixology_theme_options', $fixology_toptions);
	}
	return $data;
}
}






if( !function_exists('tmte_fixology_options_page') ){
function tmte_fixology_options_page(){
	
	// Commong elements
	$fixology_toptions	= get_option('fixology_theme_options');
	$social_list	= array(
						'Facebook'		=> 'facebook',
						'Twitter'		=> 'twitter',
						'Google Plus'	=> 'gplus',
						'Pinterest'		=> 'pinterest',
						'LinkedIn'		=> 'linkedin',
						'Stumbleupon'	=> 'stumbleupon',
						'Tumblr'		=> 'tumblr',
						'Reddit'		=> 'reddit',
						'Digg'			=> 'digg',
					);
	
	
	
	?>
	<div class="wrap"> 
		<?php screen_icon(); ?>
		<h1>Fixology Extra Options</h1>
		
		<form method="post" action="options.php">
		
			<?php settings_fields( 'tmte_fixology_options_group' ); ?>

			<p>This page will set some extra options for Fixology theme. So it will be stored even when you change theme.</p>
			<br><br>
			
			
			<h2>Select Social Share Service (for single Post or Portfolio)</h2>
			<p>The selected social service icon will be visible on single view so user can share on social sites.</p>
			<table class="form-table">
				<tr valign="top">
					<th scope="row"><label for="tmte_fixology_option_name"> Select Social Share Service for Blog Section </label></th>
					<td>
						<p>
						
						<?php
						
						// Getting from Theme Options
						$tmte_fixology_social_share_blog = array();
						if( !empty($fixology_toptions['post_social_share_services']) ){
							$tmte_fixology_social_share_blog = $fixology_toptions['post_social_share_services'];
							
						}
						
						// Now setting checkboxes in Plugin Options
						foreach( $social_list as $social_name=>$social_slug ){
							$checked = '';
							if( is_array($tmte_fixology_social_share_blog) && in_array( $social_slug, $tmte_fixology_social_share_blog ) ){
								$checked = 'checked="checked"';
							}
							echo '<label><input name="tmte_fixology_social_share_blog[]" type="checkbox" value="'.$social_slug.'" '.$checked.'> ' . $social_name . '</label> <br/>';
						}
						
						?>
						
						</p>
					</td>
				</tr>
				
				
				
				
				
				<!-- ---------- -->
				<tr valign="top">
					<th scope="row"><label for="tmte_fixology_option_name"> Select Social Share Service for Portfolio Section </label></th>
					<td>
						<p>
						
						<?php
						
						// Getting from Theme Options
						$tmte_fixology_social_share_portfolio = array();
						if( !empty($fixology_toptions['portfolio_social_share_services']) ){
							$tmte_fixology_social_share_portfolio = $fixology_toptions['portfolio_social_share_services'];
							
						}
						
						// Now setting checkboxes in Plugin Options
						foreach( $social_list as $social_name=>$social_slug ){
							$checked = '';
							if( is_array($tmte_fixology_social_share_portfolio) && in_array( $social_slug, $tmte_fixology_social_share_portfolio ) ){
								$checked = 'checked="checked"';
							}
							echo '<label><input name="tmte_fixology_social_share_portfolio[]" type="checkbox" value="'.$social_slug.'" '.$checked.'> ' . $social_name . '</label> <br/>';
						}
						
						?>
						
						</p>
					</td>
				</tr>
				
				
				
				
			</table>
			<?php  submit_button(); ?>
		</form>
		
	</div>
	<?php
}
}



/*******
 *  Social Share links creations
 */
if ( !function_exists( 'thememount_social_share_links' ) ){
function thememount_social_share_links( $post_type='portfolio' ){
	$post_type = esc_attr($post_type);
	
	if( !empty($post_type) ){
		
		$post_type = esc_attr($post_type);
		
		${ $post_type.'_social_share_services' } = thememount_get_option( $post_type.'_social_share_services' );
		
		$return = '';
		
		if( !empty( ${ $post_type.'_social_share_services' } ) && is_array( ${$post_type.'_social_share_services'} ) && count( ${$post_type.'_social_share_services'} > 0 ) ){
			foreach( ${$post_type.'_social_share_services'} as $social ){
				
				switch($social){
					case 'facebook':
						$link = '//web.facebook.com/sharer/sharer.php?u='.urlencode(get_permalink()). '&_rdr';
						break;
						
					case 'twitter':
						$link = '//twitter.com/share?url='. get_permalink();
						break;
					
					case 'gplus':
						$link = '//plus.google.com/share?url='. get_permalink();
						break;
					
					case 'pinterest':
						$link = '//www.pinterest.com/pin/create/button/?url='. get_permalink();
						break;
						
					case 'linkedin':
						$link = '//www.linkedin.com/shareArticle?mini=true&url='. get_permalink();
						break;
						
					case 'stumbleupon':
						$link = '//stumbleupon.com/submit?url='. get_permalink();
						break;
					
					case 'tumblr':
						$link = '//tumblr.com/share/link?url='. get_permalink();
						break;
						
					case 'reddit':
						$link = '//reddit.com/submit?url='. get_permalink();
						break;
						
					case 'digg':
						$link = '//www.digg.com/submit?url='. get_permalink();
						break;
						
				} // switch end here
				
				// Now preparing the icon
				$return .= '<li class="tm-social-share tm-social-share-'. $social .'">
				<a href="javascript:void(0)" onClick="TMSocialWindow=window.open(\''. esc_url($link) .'\',\'TMSocialWindow\',width=600,height=100); return false;"><i class="tm-fixology-icon-'. sanitize_html_class($social) .'"></i></a>
				</li>';
				
			}  // foreach
			
		} // if
		
		// preparing final output
		if( $return != '' ){
			$return = '<div class="tm-social-share-links"><ul>'. $return .'</ul></div>';
		}
		
	}
	
	// return data
	return $return;
	
}
}





// Show Featured image in the admin section
add_filter( 'manage_post_posts_columns', 'thememount_post_set_featured_image_column' );
add_action( 'manage_post_posts_custom_column' , 'thememount_post_set_featured_image_column_content', 10, 2 );
if ( ! function_exists( 'thememount_post_set_featured_image_column' ) ) {
function thememount_post_set_featured_image_column($columns) {
	$new_columns = array();
	foreach( $columns as $key=>$val ){
		$new_columns[$key] = $val;
		if( $key=='title' ){
			$new_columns['thememount_featured_image'] = esc_html__( 'Featured Image', 'fixology' );
		}
	}
	return $new_columns;
}
}
if ( ! function_exists( 'thememount_post_set_featured_image_column_content' ) ) {
function thememount_post_set_featured_image_column_content( $column, $post_id ) {
	if( $column == 'thememount_featured_image' ){
		if ( has_post_thumbnail($post_id) ) {
			the_post_thumbnail('thumbnail');
		} else {
			echo '<img style="max-width:75px;height:auto;" src="' . TMTE_URI . '/images/admin-no-image.png" />';
		}
	}
}
}




if( !function_exists('thememount_author_socials') ){
function thememount_author_socials( $contactmethods ) {
	$contactmethods['twitter']  = esc_html__( 'Twitter Link', 'fixology' );  // Add Twitter
	$contactmethods['facebook'] = esc_html__( 'Facebook Link', 'fixology' );  //add Facebook
	$contactmethods['linkedin'] = esc_html__( 'LinkedIn Link', 'fixology' );  //add LinkedIn
	$contactmethods['gplus']    = esc_html__( 'Google Plus Link', 'fixology' );  //add Google Plus
	return $contactmethods;
}
}
add_filter('user_contactmethods','thememount_author_socials',10,1);






/**
 * Login page logo link
 */
if( !function_exists('tm_loginpage_custom_link') ){
function tm_loginpage_custom_link() {
	return esc_url( home_url( '/' ) );
}
}
add_filter('login_headerurl','tm_loginpage_custom_link');




/**
 * Login page logo link title
 */
if( !function_exists('tm_change_title_on_logo') ){
function tm_change_title_on_logo() {
	return esc_attr( get_bloginfo( 'name', 'display' ) );
}
}
add_filter('login_headertitle', 'tm_change_title_on_logo');







/**
 *  add skincolor class style
 */
add_action( 'admin_head', 'thememount_admin_skincolor_css' );
function thememount_admin_skincolor_css(){
	global $fixology_theme_options;
	if( !empty($fixology_theme_options['skincolor']) ){
	?>
	<style>
		.tm_vc_colored-dropdown .skincolor,
		.vc_colored-dropdown .skincolor,
		.vc_btn3.vc_btn3-color-skincolor{  /* VC button */
			background-color: <?php echo esc_html($fixology_theme_options['skincolor']); ?> !important;
			color: #fff !important;
		}
		.vc_btn3.vc_btn3-color-skincolor.vc_btn3-style-outline{
			color: <?php echo esc_html($fixology_theme_options['skincolor']); ?> !important;
			border-color: <?php echo esc_html($fixology_theme_options['skincolor']); ?> !important;
			background-color: transparent !important;
		}
		.vc_btn3.vc_btn3-color-skincolor.vc_btn3-style-3d {
			box-shadow: 0 4px rgba(<?php echo thememount_hex2rgb($fixology_theme_options['skincolor']); ?>, 0.73), 0 4px rgb(0, 0, 0) !important;
		}
		
		.vc_btn3.vc_btn3-style-text.vc_btn3-color-skincolor{ /* Normal Text style button */
			color: <?php echo esc_html($fixology_theme_options['skincolor']); ?> !important;
			background-color: transparent !important;
		}
		
	</style>
	<?php
	}
}








 

/**
 *  Login page stylesheet
 */
if( !function_exists('thememount_login_page_css') ){
function thememount_login_page_css() {
	$fixology_theme_options = get_option('fixology_theme_options');
	
	$bg_size = '';
	$return  = '.login #backtoblog a, .login #nav a{color: white; text-shadow: 1px 1px black;}
	.login #backtoblog a:hover, .login #nav a:hover{color: white; text-decoration: underline;}
	';
	
	// Custom CSS Code for login page only
	if( isset($fixology_theme_options['login_custom_css_code']) && trim($fixology_theme_options['login_custom_css_code'])!='' ){
		$return .= $fixology_theme_options['login_custom_css_code'];
	}
	
	// Login page background
	$return .= thememount_get_background_css('body.login', $fixology_theme_options['login_background']);
	
	
	$logo_a_tag = '';
	$image      = '';
	$imgwidth   = '';
	$imgheight  = '';
	$bg_size    = '';
	
	if( !empty($fixology_theme_options['logoimg']) ){
		
		if( !empty($fixology_theme_options['logoimg']['full-url']) ){
			
			$image = $fixology_theme_options['logoimg']['full-url'];  // Image src
			
			if( function_exists('getimagesize') ){
				$imgsize_array = getimagesize( $fixology_theme_options['logoimg']['full-url'] );
				$imgwidth      = $imgsize_array[0];  // Image width
				$imgheight     = $imgsize_array[1];  // Image height
			}
			
		} else if( isset($fixology_theme_options['logoimg']['id']) && trim($fixology_theme_options['logoimg']['id'])!='' ){
			$image     = wp_get_attachment_image_src( $fixology_theme_options['logoimg']['id'], 'full' );
			$imgwidth  = $image[1];  // Image width
			$imgheight = $image[2];  // Image height
			$image     = $image[0];  // Image src
		}
		
		if( !empty($imgwidth) && $imgwidth>320 ){
			$imgheight = ceil( ($imgheight / $imgwidth) * 320 );
			$imgwidth  = 320;
			$bg_size   = 'background-size: 100%;';
		}
		
		
		
		if( !empty($image) ){
			$logo_a_tag .= 'background-image: url("'. $image .'");';
		}
		if( !empty($imgwidth) ){
			$logo_a_tag .= 'width:'. $imgwidth .'px;';
		}
		if( !empty($imgheight) ){
			$logo_a_tag .= 'height:'. $imgheight .'px;';
		}
	}
	
	// Login button
	if( !empty($fixology_theme_options['skincolor']) ){
		$return .= '#wp-submit{background-color:'. $fixology_theme_options['skincolor'] .'}';
	}
	
	if( !empty($logo_a_tag) ){
		$return .= '.login #login form{background-color: #f7f7f7; box-shadow: none;}';
		$return .= '.login #login h1 a{ background-size:cover; '. $logo_a_tag .' '. $bg_size .' }';
	}
	
	// Remove text shadow from login button
	$return .= '.wp-core-ui #login .button-primary {text-shadow: none;}';
	
	if( !empty($return) ){
		echo '<style type="text/css"> /* ThemeMount CSS for login page */ '. $return .'</style>';
	}
	
}
}
add_action('login_head', 'thememount_login_page_css');





