<?php
// [tm-heading tag="h1" text="This is heading text"]
if( !function_exists('thememount_sc_heading') ){
function thememount_sc_heading( $atts, $content=NULL ){
	
	$return = '';
	
	if( function_exists('vc_map') ){
		
		global $tm_sc_params_heading;
		$options_list = tm_create_options_list($tm_sc_params_heading);
		
		extract( shortcode_atts(
			$options_list
		, $atts ) );
		
		// Getting a unique class name applied by the Custom CSS box (via "css_editor") and also custom class name via "el_class".
		$css_class = '';
		if( !empty($css) ){
			$css_class = vc_shortcode_custom_css_class( $css, ' ' ) . ( strlen( $el_class ) ? ' ' . $el_class : '' );
		}
		
		// CSS Animation
		if( ! empty( $css_animation ) ) {
			$css_class .= ' ' . tm_getCSSAnimation( $css_animation );
		}
		
		
		
		$ctaShortcode = '[tm-cta';
		foreach( $options_list as $key=>$val ){
			if( trim( ${$key} )!=''  ){
				$ctaShortcode .= ' '.$key.'="'.${$key}.'" ';
			}
		}
		$ctaShortcode .= ' add_button="no" i_css_animation="" css_animation=""]'.$content.'[/tm-cta]';

		
		if( !empty($h2)!='' ) {
			
			$cta = do_shortcode($ctaShortcode);
		
			// Changing header order if reverser order
			/*if($reverse_heading == 'true' && $h4 != ''){
				$cta = thememount_change_heading_order($cta);
			}*/
			
			$return .= '<div class="tm-element-heading-wrapper tm-heading-inner tm-element-align-'.$txt_align.' tm-seperator-'.$seperator.' tm-heading-style-'.$heading_style.' '.$css_class.'">';
			$return .= $cta;
		$return .= '</div> <!-- .tm-element-heading-wrapper container --> ';
			$return .= ($css!='') ? '<style>'.$css.'</style>' : $css ; // Custom CSS style like padding, margin etc.
		}
		
		
	} else {
		$return .= '<!-- Visual Composer plugin not installed. Please install it to make this shortcode work. -->';
	}
		
	
	return $return;
}
}
add_shortcode( 'tm-heading', 'thememount_sc_heading' );