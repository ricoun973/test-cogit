<?php
// [tm-contactbox]
if( !function_exists('thememount_sc_contactbox') ){
function thememount_sc_contactbox( $atts, $content=NULL ){
	
	$return = '';
	
	if( function_exists('vc_map') ){
		
		global $tm_sc_params_contactbox;
		$options_list = tm_create_options_list($tm_sc_params_contactbox);
		
		extract( shortcode_atts(
			$options_list
		, $atts ) );
		
		$class = array( 'fixology_contact_widget_wrapper', 'thememount_vc_contact_wrapper' );
		
		
		// CSS Animation
		if ( !empty( $css_animation ) ) {
			$class[] = tm_getCSSAnimation( $css_animation );
		}
		
		// Extra Class
		if( !empty($el_class) ){
			$class[] = $el_class;
		}
		
		// VC custom class
		if ( ! empty( $css ) ) {
			$class[] = tm_vc_shortcode_custom_css_class( $css );
		}
		
		
		$class = implode(' ', $class );
		
		$return = '<ul class="' . $class . '">';
		if( trim($phone)!='' ) {
			$return .= '<li class="thememount-contact-phonenumber tm-fixology-icon-mobile">'.esc_attr($phone).'</li>';
		}
		if( trim($email)!='' ) {
			$return .= '<li class="thememount-contact-email tm-fixology-icon-comment-1"><a href="mailto:'.trim($email).'">'.trim($email).'</a></li>';
		}
		if( trim($website)!='' ) {
			$return .= '<li class="thememount-contact-website tm-fixology-icon-world"><a href="'.esc_url(thememount_addhttp($website)).'">'.esc_url($website).'</a></li>';
		}
		if( trim($address)!='' ) {
			$return .= '<li class="thememount-contact-address  tm-fixology-icon-location-pin">' . thememount_wp_kses($address) . '</li>';
		}
		if( trim($time)!='' ) {
			$return .= '<li class="thememount-contact-time tm-fixology-icon-clock">' . thememount_wp_kses($time) . '</li>';
		}
		$return .= '</ul>';
		
	} else {
		$return .= '<!-- Visual Composer plugin not installed. Please install it to make this shortcode work. -->';
	}
	
	return $return;
}
}
add_shortcode( 'tm-contactbox', 'thememount_sc_contactbox' );