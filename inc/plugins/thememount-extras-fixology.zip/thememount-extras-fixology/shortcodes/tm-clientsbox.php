<?php
// [tm-clients]
if( !function_exists('thememount_sc_clients') ){
function thememount_sc_clients($atts, $content=NULL ) {

	$return = '';
	
	if( function_exists('vc_map') ){

		global $fixology_theme_options;
		global $tm_sc_params_clients;
		$list_of_clients 	= array();
		$finalkeys			= array();
		
		$options_list = tm_create_options_list($tm_sc_params_clients);
		
		extract( shortcode_atts(
			$options_list
		, $atts ) );
		
		
		
		// Starting wrapper of the whole arear
		$return .= thememount_box_wrapper( 'start', 'client', get_defined_vars() );
		
		// Heading element
		$return .= tm_vc_element_heading( get_defined_vars() );
		
		// Getting $args for WP_Query
		$args = thememount_get_query_args( 'client', get_defined_vars() );
		
		// Wp query to fetch posts
		$posts = new WP_Query( $args );
		
		if ( $posts->have_posts() ) {
			$return .= thememount_get_boxes( 'client', get_defined_vars() );
		}

		// Ending wrapper of the whole arear
		$return .= thememount_box_wrapper( 'end', 'client', get_defined_vars() );
		
		/* Restore original Post Data */
		wp_reset_postdata();
		
	} else {
		$return .= '<!-- Visual Composer plugin not installed. Please install it to make this shortcode work. -->';
	}
		
	return $return;
}
}
add_shortcode( 'tm-clientsbox', 'thememount_sc_clients' );