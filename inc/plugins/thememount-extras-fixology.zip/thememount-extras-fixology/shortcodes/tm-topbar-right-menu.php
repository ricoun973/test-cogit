<?php
// [tm-topbar-right-menu]
if( !function_exists('thememount_sc_topbarrightmenu') ){
function thememount_sc_topbarrightmenu( $atts, $content=NULL ){
	$return = '';
	if( has_nav_menu('tm-topbar-right-menu') ){
		$return .= wp_nav_menu( array( 'theme_location' => 'tm-topbar-right-menu', 'menu_class' => 'topbar-nav-menu', 'container' => false, 'echo' => false ) );
	}
	return $return;
}
}
add_shortcode( 'tm-topbar-right-menu', 'thememount_sc_topbarrightmenu' );