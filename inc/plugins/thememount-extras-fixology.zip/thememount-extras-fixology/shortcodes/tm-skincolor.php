<?php
// [tm-skincolor]This text will be in skin color[/tm-skincolor]
if( !function_exists('thememount_sc_skincolor') ){
function thememount_sc_skincolor( $atts, $content=NULL ) {
	return '<span class="thememount-skincolor tm-skincolor">'.$content.'</span>';
}
}
add_shortcode( 'tm-skincolor', 'thememount_sc_skincolor' );