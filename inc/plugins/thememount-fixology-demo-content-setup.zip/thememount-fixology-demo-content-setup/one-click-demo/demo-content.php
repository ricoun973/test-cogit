<?php



/*************** Demo Content Settings *******************/
function thememount_action_rss2_head(){
	// Get theme configuration
	$sidebars = get_option('sidebars_widgets');
	// Get Widgests configuration
	$sidebars_config = array();
	foreach ($sidebars as $sidebar => $widget) {
		if ($widget && is_array($widget)) {
			foreach ($widget as $name) {
				$name = preg_replace('/-\d+$/','',$name);
				$sidebars_config[$name] = get_option('widget_'.$name);
			}
		}
	}
	
	// Get Menus
	$locations = get_nav_menu_locations();
	$menus     = wp_get_nav_menus();
	$menuList  = array();
	foreach( $locations as $location => $menuid ){
		if( $menuid!=0 && $menuid!='' && $menuid!=false ){
			if( is_array($menus) && count($menus)>0 ){
				foreach( $menus as $menu ){
					if( $menu->term_id == $menuid ){
						$menuList[$location] = $menu->name;
					}
				}
			}
		}
	}
	
	$config = array(
			'page_for_posts'   => get_the_title( get_option('page_for_posts') ),
			'show_on_front'    => get_option('show_on_front'),
			'page_on_front'    => get_the_title( get_option('page_on_front') ),
			'posts_per_page'   => get_option('posts_per_page'),
			'sidebars_widgets' => $sidebars,
			'sidebars_config'  => $sidebars_config,
			'menu_list'        => $menuList,
		);            
	if ( defined('THEMEMOUNT_THEME_DEVELOPMENT') ) {
		echo sprintf('<wp:theme_custom>%s</wp:theme_custom>', base64_encode(serialize($config)));
	}
}

if ( defined('THEMEMOUNT_THEME_DEVELOPMENT') ) {
	add_action('rss2_head', 'thememount_action_rss2_head');
}

/**********************************************************/




/********************* Ajax Callback Init **************************/
add_action( 'admin_footer', 'thememount_one_click_js_code' );
function thememount_one_click_js_code() {
	$images   = array();
	$images[] = get_template_directory_uri() . '/cs-framework-override/fields/thememount_one_click_demo_content/import-alert.jpg';
	$images[] = get_template_directory_uri() . '/cs-framework-override/fields/thememount_one_click_demo_content/import-loader.gif';
	$images[] = get_template_directory_uri() . '/cs-framework-override/fields/thememount_one_click_demo_content/import-success.jpg';
	
	?>
	<script type="text/javascript" >
	jQuery(document).ready(function($) {
		
		/*********** Preload images **************/
		function preload(arrayOfImages) {
			$(arrayOfImages).each(function(){
				$('<img/>')[0].src = this;
				// Alternatively you could use:
				// (new Image()).src = this;
			});
		}
		preload([
			<?php
			$total = count($images);
			$x     = 1;
			foreach( $images as $image ){
				echo '"'. $image . '"' ;
				if( $total != $x ){
					echo ',';
				}
				$x++;
			}
			?>
		]);
		/*****************************************/
		
	});
	</script>
	<?php
}




if( !class_exists( 'thememount_fixology_one_click_demo_setup' ) ) {
	

	class thememount_fixology_one_click_demo_setup{
		
		
		function __construct(){
			add_action( 'wp_ajax_fixology_install_demo_data', array( &$this , 'ajax_install_demo_data' ) );
		}
		
		
		/**
		 * Decide if the given meta key maps to information we will want to import
		 *
		 * @param string $key The meta key to check
		 * @return string|bool The key if we do want to import, false if not
		 */
		function is_valid_meta_key( $key ) {
			// skip attachment metadata since we'll regenerate it from scratch
			// skip _edit_lock as not relevant for import
			if ( in_array( $key, array( '_wp_attached_file', '_wp_attachment_metadata', '_edit_lock' ) ) )
				return false;
			return $key;
		}
		
		
		
		
		/**
		 * Added to http_request_timeout filter to force timeout at 60 seconds during import
		 * @return int 60
		 */
		function bump_request_timeout() {
			return 600;
		}
		
		
		
		/**
		 * Map old author logins to local user IDs based on decisions made
		 * in import options form. Can map to an existing user, create a new user
		 * or falls back to the current user in case of error with either of the previous
		 */
		function get_author_mapping() {
			
			if ( ! isset( $_POST['imported_authors'] ) )
				return;

			$create_users = $this->allow_create_users();

			foreach ( (array) $_POST['imported_authors'] as $i => $old_login ) {
				// Multisite adds strtolower to sanitize_user. Need to sanitize here to stop breakage in process_posts.
				$santized_old_login = sanitize_user( $old_login, true );
				$old_id = isset( $this->authors[$old_login]['author_id'] ) ? intval($this->authors[$old_login]['author_id']) : false;

				if ( ! empty( $_POST['user_map'][$i] ) ) {
					$user = get_userdata( intval($_POST['user_map'][$i]) );
					if ( isset( $user->ID ) ) {
						if ( $old_id )
							$this->processed_authors[$old_id] = $user->ID;
						$this->author_mapping[$santized_old_login] = $user->ID;
					}
				} else if ( $create_users ) {
					if ( ! empty($_POST['user_new'][$i]) ) {
						$user_id = wp_create_user( $_POST['user_new'][$i], wp_generate_password() );
					} else if ( $this->version != '1.0' ) {
						$user_data = array(
							'user_login' => $old_login,
							'user_pass' => wp_generate_password(),
							'user_email' => isset( $this->authors[$old_login]['author_email'] ) ? $this->authors[$old_login]['author_email'] : '',
							'display_name' => $this->authors[$old_login]['author_display_name'],
							'first_name' => isset( $this->authors[$old_login]['author_first_name'] ) ? $this->authors[$old_login]['author_first_name'] : '',
							'last_name' => isset( $this->authors[$old_login]['author_last_name'] ) ? $this->authors[$old_login]['author_last_name'] : '',
						);
						$user_id = wp_insert_user( $user_data );
					}

					if ( ! is_wp_error( $user_id ) ) {
						if ( $old_id )
							$this->processed_authors[$old_id] = $user_id;
						$this->author_mapping[$santized_old_login] = $user_id;
					} else {
						printf( __( 'Failed to create new user for %s. Their posts will be attributed to the current user.', 'fixology-demosetup' ), esc_html($this->authors[$old_login]['author_display_name']) );
						if ( defined('IMPORT_DEBUG') && IMPORT_DEBUG )
							echo ' ' . $user_id->get_error_message();
						echo '<br />';
					}
				}

				// failsafe: if the user_id was invalid, default to the current user
				if ( ! isset( $this->author_mapping[$santized_old_login] ) ) {
					if ( $old_id )
						$this->processed_authors[$old_id] = (int) get_current_user_id();
					$this->author_mapping[$santized_old_login] = (int) get_current_user_id();
				}
			}
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/**
		 * Install demo data
		 **/
		function ajax_install_demo_data() {
		
			// Maximum execution time
			@ini_set('max_execution_time', 60000);
			@set_time_limit(60000);

			define('WP_LOAD_IMPORTERS', true);
			include_once( FIXOLOGY_TMDC_DIR .'one-click-demo/wordpress-importer/wordpress-importer.php' );
			$included_files = get_included_files();


			$WP_Import = new thememount_WP_Import;
			
			$WP_Import->fetch_attachments = true;
			
			// Getting layout type
			$layout_type = 'default';
			/*if( isset($_POST['layout_type']) && !empty($_POST['layout_type']) ){
				$layout_type = strtolower($_POST['layout_type']);
				$layout_type = str_replace(' ','-',$layout_type);
				$layout_type = str_replace(' ','-',$layout_type);
				$layout_type = str_replace(' ','-',$layout_type);
				$layout_type = str_replace(' ','-',$layout_type);
			}*/
			
			
			// getting layout type for correct XML file
			//$filename = 'demo-'.$layout_type.'.xml';
			$filename = 'demo.xml';
			//if( !empty($layout_type) && $layout_type=='overlay' ){ $filename = 'demo-overlay.xml'; }
			
			$WP_Import->import_start( FIXOLOGY_TMDC_DIR .'one-click-demo/'.$filename );
			
			
			$_POST       = stripslashes_deep( $_POST );
			$subaction   = $_POST['subaction'];
			if( !empty($_POST['layout_type']) ){
				$layout_type = $_POST['layout_type'];
				$layout_type = strtolower($layout_type);
				$layout_type = str_replace(' ','-',$layout_type);
				$layout_type = str_replace(' ','-',$layout_type);
				$layout_type = str_replace(' ','-',$layout_type);
				$layout_type = str_replace(' ','-',$layout_type);
			}
			$data        = isset( $_POST['data'] ) ? unserialize( base64_decode( $_POST['data'] ) ) : array();
			$answer      = array();
			echo '';  //Patch for ob_start()   If you remove this the ob_start() will not work.
			
			
			switch( $subaction ) {
				
				case( 'start' ):
				
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_cat';
					$answer['message']        = __('Inserting Categories...', 'fixology-demosetup');
					$answer['data']           = '';
					$answer['layout_type']	  = $layout_type;
				
					die( json_encode( $answer ) );
				
				break;
				
				
				case( 'install_demo_cat' ):
					wp_suspend_cache_invalidation( true );
					$WP_Import->process_categories();
					wp_suspend_cache_invalidation( false );
					
					// Output message
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_tags';
					$answer['message']        = __('All Categories were inserted successfully. Inserting Tags...', 'fixology-demosetup');
					$answer['data']           = base64_encode( serialize( $data ) );
					$answer['layout_type']	  = $layout_type;
					
					die( json_encode( $answer ) );
				break;
				
				case( 'install_demo_tags' ):
					wp_suspend_cache_invalidation( true );
					$WP_Import->process_tags();
					wp_suspend_cache_invalidation( false );
					
					// Output message
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_terms';
					$answer['message']        = __('All Tags were inserted successfully. Inserting Terms...', 'fixology-demosetup');
					$answer['data']           = base64_encode( serialize( $data ) );
					$answer['layout_type']	  = $layout_type;
					
					die( json_encode( $answer ) );
				break;
				
				case( 'install_demo_terms' ):
					
					wp_suspend_cache_invalidation( true );
					ob_start();
					$WP_Import->process_terms();
					ob_end_clean();
					wp_suspend_cache_invalidation( false );
					
					// Output message
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_posts';
					$answer['message']        = __('All Terms were inserted successfully. Inserting Posts...', 'fixology-demosetup');
					$answer['data']           = base64_encode( serialize( $data ) );
					$answer['layout_type']	  = $layout_type;
					
					die( json_encode( $answer ) );
				break;
				
				
				case( 'install_demo_posts' ):
					//wp_suspend_cache_invalidation( true );
					echo '';  //Patch for ob_start()   If you remove this the ob_start() will not work.
					ob_start();
					echo '';  //Patch for ob_start()   If you remove this the ob_start() will not work.
					$WP_Import->process_posts();
					ob_end_clean();
					//wp_suspend_cache_invalidation( false );
					
					// Output message
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_images';
					$answer['message']        = __('All Posts were inserted successfully. Importing images...', 'fixology-demosetup');
					$answer['data']           = base64_encode( serialize( $data ) );
					$answer['layout_type']	  = $layout_type;
					$answer['missing_menu_items']   = base64_encode( serialize( $WP_Import->missing_menu_items ) );
					$answer['processed_terms']      = base64_encode( serialize( $WP_Import->processed_terms ) );
					$answer['processed_posts']      = base64_encode( serialize( $WP_Import->processed_posts ) );
					$answer['processed_menu_items'] = base64_encode( serialize( $WP_Import->processed_menu_items ) );
					$answer['menu_item_orphans']    = base64_encode( serialize( $WP_Import->menu_item_orphans ) );
					$answer['url_remap']            = base64_encode( serialize( $WP_Import->url_remap ) );
					$answer['featured_images']      = base64_encode( serialize( $WP_Import->featured_images ) );
					
					die( json_encode( $answer ) );
				break;
				
				
				
				case( 'install_demo_images' ):
					$WP_Import->missing_menu_items   = unserialize( base64_decode( $_POST['missing_menu_items'] ) );
					$WP_Import->processed_terms      = unserialize( base64_decode( $_POST['processed_terms'] ) );
					$WP_Import->processed_posts      = unserialize( base64_decode( $_POST['processed_posts'] ) );
					$WP_Import->processed_menu_items = unserialize( base64_decode( $_POST['processed_menu_items'] ) );
					$WP_Import->menu_item_orphans    = unserialize( base64_decode( $_POST['menu_item_orphans'] ) );
					$WP_Import->url_remap            = unserialize( base64_decode( $_POST['url_remap'] ) );
					$WP_Import->featured_images      = unserialize( base64_decode( $_POST['featured_images'] ) );
					
					//var_dump($WP_Import->missing_menu_items);
					//var_dump($WP_Import->processed_terms);
					//var_dump($WP_Import->processed_posts);
					//var_dump($WP_Import->processed_menu_items);
					//var_dump($WP_Import->menu_item_orphans);
					
					ob_start();
					$WP_Import->backfill_parents();
					$WP_Import->backfill_attachment_urls();
					$WP_Import->remap_featured_images();
					$WP_Import->import_end();
					ob_end_clean();
					
					// Output message
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_slider';
					$answer['message']        = __('All Images were inserted successfully. Inserting demo sliders...', 'fixology-demosetup');
					$answer['data']           = base64_encode( serialize( $data ) );
					$answer['layout_type']	  = $layout_type;
					
					die( json_encode( $answer ) );
				break;
				
				
				
				
				case( 'install_demo_slider' ):
					
					$json_message		= __('RevSlider plugin not found. Setting the widgets and options...', 'fixology-demosetup');
					
					if ( class_exists( 'RevSlider' ) ){
						$json_message	= __('All demo sliders inserted successfully. Setting the widgets and options...', 'fixology-demosetup');
						
						// List of slider backup ZIP that we will import
						$slider_array	= array(
							FIXOLOGY_TMDC_DIR . 'sliders/fixology-mainslider.zip',
							FIXOLOGY_TMDC_DIR . 'sliders/fixology-overlay-mainslider.zip',
							FIXOLOGY_TMDC_DIR . 'sliders/shop-mainslider.zip',
						);
						
						$slider			= new RevSlider();
						foreach($slider_array as $filepath){
							if( file_exists($filepath) ){
								$result = $slider->importSliderFromPost(true,true,$filepath);  
							}
						}

					}
					
					// Output message
					$answer['answer']         = 'ok';
					$answer['next_subaction'] = 'install_demo_settings';
					$answer['message']        = $json_message;
					$answer['data']           = base64_encode( serialize( $data ) );
					$answer['layout_type']	  = $layout_type;
					
					die( json_encode( $answer ) );
					
				break;
				
				
				
				
				
				case( 'install_demo_settings' ):
					
					
					/**** Breacrumb NavXT related changes ****/
					$breadcrumb_navxt_settings						= array();
					$breadcrumb_navxt_settings['hseparator']		= '<span class="tm-bread-sep"> &nbsp; &rarr; &nbsp;</span>';  // General > Breadcrumb Separator
					$breadcrumb_navxt_settings['Hhome_template']	= '<span typeof="v:Breadcrumb"><a rel="v:url" property="v:title" title="Go to %title%." href="%link%" class="%type%"><i class="fa fa-home"></i><span class="hide">%htitle%</span></a></span> ';  // General > Home Template
					$breadcrumb_navxt_settings['Hhome_template_no_anchor']	= '<span property="itemListElement" typeof="ListItem"><span property="name">%htitle%</span><meta property="position" content="%position%"></span>';  // General > Home Template
					
					// Getting existing settings
					$bcn_options    = get_option('bcn_options');
					if( !empty($bcn_options) && is_array($bcn_options) ){
						// options already exists... so merging changes with existing options
						$breadcrumb_navxt_settings = array_merge($bcn_options, $breadcrumb_navxt_settings);
					}
					update_option( 'bcn_options', $breadcrumb_navxt_settings );
					
					/**** Finish Breadcrumb NavXT changes ****/
					
					
					
					/**** START CodeStart theme options import ****/
					
					$theme_options = array();
					
					$theme_options['default']	= 'eNrlXFzpjtw4kv7fQL8DXCcbixljS1k68na5dj22e3oWvuAqT29j0RCYKWamXFy6ICnrGMPAvMM8xb7GPso-yUbwEqVMqbIu24V1znRlUkEy-DEYjAgGRWeuO5x9LmbTWa84C5NFGqV572kxG896P7HAmbsD_DWa9VwiepVuSvwxmPUuwoDhV2cy6y03UeRjgc9cIhazpCx6T-nMmX0OZ7aoumY0YNDqF6hcMO2uonROI39OF2erPN0kAdKPkYnhrBfGdMWbtmc9yQcvCgOjENrMWcZoaZQBXCdZWoRlmCZGqQN_aVnSxRo5Mx7AIIrw72ZP0Hlt9MsJfgTX0GGYJCz__pnm_zjTMKNRisCH8cpsfFKVA4v-YlOUaWwSuDBFDAYLc7RMsX-KHH3mI1jSOIyuZG8faMQuKP_leLMeYrPJrIrEhQqndJ3G9ID8BVo8h78FTQqrgM6XspFzmodUjHKMCK02EeXDcWC0JbssrTKHOss0N5mEwSFvloIDeHa4pDoODC9MmLVm4WpdymdCirHFiJUly61cIqOLMOG4QAVnF5TTMX4UXCI0iixkVcg3b1TM2UBwXCJneJWmq4gJobE5XCdnltlqwJZ0E5V6XCL0c8sYOTT5k23bnGhUI1qn50wzaNtjb7HgVMD72vFxncGg9KxNtyYNeXoDT2ECciGIu1wnDlh7DtMSHZBfWHTOynBxzdRBK0PJ8Q2nbWC3T9vA65w2d9e0OWP8dM8MwuU-Tri8YQdcXPbDweU9Urg6pEtC-SBwDR5cJ1xcbod0eQ8oXcNHCleHdLkPKF2jxwmX0yFd7gNJlyvMz2-H1fiWojW9neKCHt3-8A7CVWzm1wO2j_F3Y7DuZv51rsVxXCdgzm7ARh5-rhWvBTwBq_BxoeWM7tdYngzw042Vw_3GFSu_R60FGG2yjOULWrA2zCYdmHk3x2yfBQl155uyTBON2ejrYXYDEeseefv4gFEZNfDLsMTSrzrCu-5lrQPDGnOa-8U6veg9nc8cyTMWWqbL3_AJJYk_X_laVmBUAc3PVjm7Us6eoOmORUzRUijLbHZ4uAwvobHVVb9cXAPWMVQp-4s01uVWQEt6eJFZUpcdbjIMERSHwFwnKw5Hh67tjA_t6WGW5ulcJ7YoLXvY_5SttmMdqE3d0Z7hDhztArpjORF_9g1-8JUkPWFzVbkgcPlqTv_kePaBNzpw3fGB3R8PnujdjQOH81xcwQulF2sYXCdvwK2R8NCIX1u0QeDBP87oWNKuaRJELPfDBQ6LAqOfOW0UznOaqx1cMKEPl2IGp_ohX9b0ghVpzJS_v6RkSS2a5-mFFaQXSRUHEFVQ-0BXhQpcIpwvoIjw_1rzzXweMSUmqkajb_kT-SVlaAHOGw6Q6-0Ykb-I0oLdeVxcg_q4Ntm9jsq1t0Yl2TbnXQync94FyY559-jYXXIN4qrm5GYGZJs48av4KKA48ke6WVhJJehDXFz485zRsywNExVHdVxcoX3caRuhVcXnDHrcF1C1-GWazVE9Sw0DrImSLgWCXFwZVDsG6wROIO2psabtWDWDBlGjSb0s7QMC_3OHQ_jbd4dPlAzIyhFblrwFzjTAeBSE56Qor1wi9qxSwDPieNll7_i3dJOT0xz6YgFxB-QX-F2QX0B0r97QhJyw_DxcXDDyPk_Pw4Dlfzg6hNaOG4PKcQ_XfXogRv9VxlaRLmAXsTDwVpAyTaMyzJ71krT3e716x4QOdtC0zCU2h3tfc9qaIXm-dDXhNcp_dP_KH4CBpTtfwSxcXLZqf9edbGl_4DtJrep3-zYwT0sJ0F22AVQfXFzevAPHO3CHsAdM1R5gYtgh0Y5B9h37j3tYrV6H1TrojlF4u6zWIJhOvW6viAu_Qu-x-pOd1v4tYjs3xQ3VRrDIN_G8Azfg-13GQNlRuXHem9iN7uosebeL9bS74wz-ue617oQG8DxkFzss7GFtZSuuPIxv2sqUMLAHc0ApJeNQE8ivWLE9aWs8Bq1qy_HCxiF7psG5X1wi4QJ0br5QWv0FLdkqza_I83yxDs9ZMSNbNUq6UjUGeKy2ahCj8aaJQb2Wi4gWRbgMWaA2pPdQWpCqnMDuwXLZ18SoTjflOs1Vd1ww4HNe0GTPU0e7dSAdKTpD_djc1Zpml0Gy09xWqwYPE0HXo_BGvqr0vZzGtu5EI2358E_fdsQ-5HnYf5GBwQuA-u0gIES8BW41Vf9xnqilLesarbXbufzsd5WWV5liW4OlHinza9b7WRoIcoXj0w5VNORKJk6_n4Dg6HYBQahg79I_ro2fTv0zFijxA3cKS-Ez70zI3VwwbaORLZkt16AerE0ePYin7jiHyIflDO3LsdfPxMBkrobqdTJ5mF5Fd9Lv4kIT00u_HsCeKCkpQArOrnyVIVwi3BhUwTXF4gsyWXtsq4VRq92uZaa7KNt8FNebHOD_vQGajd4TLShiYjUrzfmtBLE2t5VqMbHnpV_EIBoQ1cdaISVZLxio5bV2-BAEXuKHSbbRO9wJLyNrlrN-v0_UQhBtcIdKSrXYDLied1FPJkvYI2Dl-ssQ6BAeX865QHIonTJe75lsUImFFdMw6R3_-MMOEh4cOUbnSjjooIGe6dgB4RpL_nrW9OTLMAbZIHyqnvWkD0XMCXwG_jn_1_tdeHk7WVADOT4qyjxNVsdgsgf0ivzvP_5Jfs5D_GpPZrbNC0AG4dvRoSQ9mufQ6AktNznSgZNJTja69ovX705evdRda0cTVV4FaYHxjWAL09G3wDRO5yEIwQOA-q_EdlxcjwyGozGZjmyniSGMXCf6d3ZJ4yxiqGR2oFYTxHId5t8JaFEKZhsYB1YGrT9cMHTugPwcLss1KcoGaK_TgjxPVixixQH5ePJ8G7RqeetohlQ9hjbFSJ9vmjiAYq71slujo2DF1rX2aLirua5A03ibtKF2twwkTxo246bOvq4zb9Bao6nqbRUldqcHrjM8GI0wSqw1vdokysSX6hqw_alp0sJTBTTw-uePv5G3736Vv1ClFyxV1uPaWacxS5NIx-8Fa23BI7S4Y7aiSGWhWZnzdEu5OTpb1auwEjpetkpZw0WAlF_Z7b6HmEWX8-gMb37Stofp5mpjxIStpRX0RRSZTxclGt0YLKxkbCBidxwPr414LxNkMtVh0iBPMzwQeKST6nZM6ugWkzrCT_ekStD2nqfdxDv80onrDpin_Hdd7b4c0utcIqa2jpiWaXZXXCeV5w0PlqPlWK8EJWlChxYsozktNWJavzuVnlKnIfoU9-tGSe8crhrdr3DucbaP6O0QHN_57jPL2zh3Hy3n3qPlfPBoOR8-Ws5Hj5bz8aPlfPJoOZ9-_5y7LTuR_f2zbssLaMs0LRsxQOCl8oz0TbWKkEbR_5ezc0xZCS9ZcAOL0JnAZ6HNaBEPlOBtpbxA5YE_8AfKKqxRm3OCFha3zcCilLyhAd2kb5ua-zKgW2WwBagdgljlmplRBM99UqVSmYPqyDXAUIcIDbbBq71cJx70rtFeAy6uj60Kd0b3oRa2M4LPVB-r1hnvztoT0n-tGuCnu03Sh5a2PfMc95e9HVjVB9Wd2aLFLLsS-U-YeMXHAQ29UKXkf_6boPpcIkeUrHO2fHadUuwdqxPDo0N63Fwnz6OI8JYKkjNw3c5Z0NdZcU0WdBgSw2MYnRUUuCX9rlMF01WYXFznY4-v19479PW2nmbnLGnX1EPnIXz2G6ppdYqEe9scBupj4kGc5kxHJoGnv_311a_kzbsPr-RvTmjkRhhcJ0AIPX_MxVwnCuOwNA9E0QPGx_P0UqooyVAJ4sFU1FFRqC6mPBHO0vOjmEWaej-YOiAumXkux670RVwinl-sQaH5hcjoK1SMQYRsXoYBAT1JXodnjJyuw4JgmsO_kROsQ8JypgJ27Q3K5FaR2oF2Al2weZqe9Z6GPOSKCXoXYckXbjhzxaBXWbQp8LdcJw_Pw-SMBRhKkrYgDlKC68espDDQgofsXFyZR8sSOo9YoFNrgUeReCFF67n-gdOUxkpKJrhI41jdREblXCLDKbZOJQlZIYUILBQmv77kX7-I0HlY6N4d7B1TZ-hKUp7SFWa3fBG709ZIsE0MrlAV1nhDPh2Q31SeyRY9NIzw6BD2LhoYQ41mV78CHpPMGVfSVAOZj6kxzmHLOK8BuH1ebgy9tAxqHG-B-Ym8UWDaDdomkM3nTRCbfW0DiNnMWZqXyzQKUz8T6f1-XDDEYVSYu_rUpMPFrY-ReWBsqc-QKiqeoZyzCAYYmCxVFPJhtaJRzX949fr56auX5P2Hd__x6sXpyXbDqlqbjkEB26berbN2tyzubVRZkKgas6XChVwnq0uJQq2hcgGcLVwiY2TQwnsBLznFQjJTU9ys03GRQCiaKlF-n4z7YhOWKvTZmnE_qmfcXCdp2XmLgGfR1Q9EUbEIoacNs-sLqtG9MLKNXFy4B4bHVvDMGcs7oRnWoZHa476QcfdDBiq9iPDtE-SlIPh6-NC8uInobAqJ5z0B5O0H0KBaXq9Bvz0wPBOFDloJHdiM69gsonQT3FwnOIP9wJka4Mi2iUwbvRlCe1_42RegG9_0Gc860zI60JLWTGN_Mi1CvUlNamSmzagxxSwrUQfsXDCnlf7-bEzcgEP0HxhaOF_EbRWj1zBZRQwvBIncBD33sOH-DfZJXCIFoFApca1VhXlgZD1wEQGMTbcB_ZFIHjG76nmLV6Drq11Vpynw5GlGYx8cgZzWpNBETMn4tJW6voe8uswYng4umDpQbKvWIeqOI07uTKV4L_ryxlf2br_Z7gMYCnL4VaHSdxxxAcQ0P7PSbwuYeyPAoO6v1fnwVxauVF5j-GZYeTfCCu8OBAGorOIOYN32lmlhnX9LrOT7IXDApvKU1y-5s2KJsJ2R2egMqhrtQRZFsaVQ0eBgMPZ8YA_8ebi6RxmcKmx5fnNhpddeTlau483Q3BqCEcyCXCLy6sOHdx-U6aIJYxaEm7hKyYNdjweDMkCZxPSKrOk5I2DrXCckhr0rIGlOAhYxcPb65M-MFJuckTIlizVbnGFAKVwnRcZcIhjOqq-41Z01krAHKgk7SUHS1UUjtMiO1t7x27RcXEMrZIkhy6NDKDnKjk_SPL86IPNNSRL5PKYldB7IvkUCN0ZAiz55HzHw30gJXhFd0TAhYCmsCc4MCcLlkmG0n5yxq4s0D4r-0WF2rASlCAOmLgQ1Ez5rz6XnXFx7Pq2e81Ubs3jO8qbLP9xJ5WOINmvQ4tRWHEnzo3ZJCgN1WxQY1uA-YbO5QUWspsS8cGXwf5GmPMCTL7aHaQxgPs-UrqqRGB1hXFy43KbAkQm7D1dcXKHjUNyCcVTUj7MkzUNhGPoJjZWm1AbgTsK6WSZ3retarYzI_dq092izZr3u16y3R7N1-3afdr-ImblYWGZut1qVwKYx61alTFVMx21QZHkabBalBbajpdYD0E6V0oZ-hKVsodq1moGtgUkhH-7q1dtNt0nKWsAJk9ZQksoceApTw6JHb4PrNjxkJvD3I17jIy8MYrW91VtYl3Eklqxbz57fJDxjno-6SkuvXCetb3Y_5pn0mO-8M9O9YBkPlR3rh2vHzILHLLrjj29fvvpAXrx7e3L64eOL07--ewta0uHEA92QvkXcA90ZM6Ey5fZESkTjApQ8zCUDfXlSwvdyk7DgD9DUQFwnytduGQya8Fxcd6Xeve_7UvYhgMrbV1e06gdN_MqYeNnXjU6aXFypmG6TErBftkgduEVRgK1cIt4IPB7zw9jg6vOPP2Q0wBmbEfsp3vvIV2FcIr5_-fGHvpzOA9Kv5hbq8MRMkQw6I3-s0kX_aKaA1ptQtcTLIUZ2dgnPjTROKBuKslr65oy4vNRkTHyXVtmMOBNOwVu_kG0lGKqPJAfbrAsm3OE2E55gjMM6Iz9NJpMdLDlbLLV2jp_-rpWLyEtxmBE6L0AFlYz3tYQmhva_wHcC_8AINX9aZ6gfqszZGeFfUT_9558soHtSFfwmClTNOP377eoVt6qW3qbWDavg7OKbQBZcXLl93hKNgZjNICyyiIKohgmf7DmYs2dYXd-QzpY-3jGq1DfG4mq2j9sg4vEYdeu1Se0Y1EW0WamdcwcNOgi6VzSWdUOkflQlY4eavsZcMG4jWxW1_yCrKU4cM3BmmWYbt_bRPKyDgayeQjF5w63GohYUaoEE-zXqmF5THReeDwOlVmW48rfNICE3Tw0-VJt_wfJCGbZN0joftlmnNkhRRfNhSz60TYyCEcYrri1QZqr7wkP-krxyLY8XXCdcIq-dv0TduGI_1G-SWORcIpnAeCMBToJu3BCMm_UwmbT3gMKke6ghvLsPbzTc2cegaxR4sxZv42mPlZuQOoBaOZpVXDBVOZfy8rG6uGFsT8br6uTTT9sPdVVUiPw2WeM6nfEUt7qipHnZeMV6g4QltTYclczSweJ0a1wwvkwcqVKQwhjn16zl4XvJGffn_ILn_Mw5Yo6-Li0Sa3R5hZP0cIpGc7W9XlXDC1BhwsEWBbho-dsvArCH1FVNP82qSl_-D9nqKzU';
					$theme_options['overlay']	= 'eNrlXFzpjhs5kv7fQL8DR43FjLGVVXnpdLl2PbZ7eha-4CpPb2PRSFBKSkpXXshM1TGGgXmHeYp9jX2UfZKN4JXMlJQl1WG7sFa7LTGDZMTHYDAYDCaduG5_8rmcjFwnvfI8SmdZnBW9p-VkOOn9xEJn6vr4azDpxfQ6W1X4w5_0LqOQ4VdnNOnNV3EcYEHAYpawtCp7T-nEmXyOJraoumQ0ZNDqF6hcMO0u4mxK42BKZ-eLXCJbpSHSD5GJ_qQXJXTBm7ZcJz3JBy-KQqMQ2ixYzmhllAFcJ3lWRlWUpUapA__SqqKzJXJmPFwwIcro72ZP0HlD-vkIP4Jr6DBKU1Z8_0zzP5xpGNE4Q-CjZGE2PqrLgcVgtiqrLDEJXFwYXCIGwsIYzTPsn1wiR5-5BHOaRPG17O0Djdkl5b8cb9JDbFa5VZO4UOGMLrOEHpC_QIsX8G9J09IqofO5bOSCFhEVUg4RocUqplxcHAekrdhVZVUF1JlnhckkCIe8WQoO4Nnhmuo4IF6UMmvJosWyks-EFmOLMasqVlhlTmdRynGBCs4mKMdD_ChEaBxbyKrQb96oGDNfcFwiR3iRZYuYCaWxOVwn55bZasjmdBVXeiD0c8uQHJr8ybZtTjRoEC2zC6YZtO2hN5txKuB96QQ4z0AoPWrjtUFDnt7AUxiAQiji5oED1p7DsMQH5BcWX7Aqmt0wdNBKX3K857D59vZh873OYXM3DZszxE_3yCBcXO7jhMvrd8BlPxxcXN4jhatDuySUDwKX_zjhcju0y3tA7eo_Urg6tMt9QO0aPE64nA7tch9Iu1xc4X5-O6yGt1St8e0MF_ToHvbvoFxc5Wp6M2C7OH97g3U3969zLg47AXM2Azbw8HOjes3gCXiFjwstZ3C_zvLIx083Vg7fNy5Y9T1aLcBoleesmNGSbcNs1IGZtz9mu0xIqDtdVVWWaswGXw-zPVSsW_Lt8gGjMmoQVFGFpV9VwruuZVsFwxpTWgTlMrvsPZ1OHMkzFlrmlr-1XCeUJMF0EWhdAalCWpwvCnatNnuCpjsWMUZPoaryydHRPLqCxhbXh9USsE6gSnU4yxJdboW0okeXuSVt2dEqxxBBeQR8svJocOTazvDIHh_lWZF9YrPKsvuHn_LFeqwDrak72DHcgdLOoDtWEPHPrsEPPpPkTticVS4oXFyxmNI_OZ594A0OXFx3eGAfDv1cJ3p148DhONfwQunlEuTkDbgNEh4aCRqTNgw9-MMZHUraJU3DmBVBNEOxKDD6mdPG0bSghVoBEPpoLkZwrB_yaU0vWZklTO3355TMqUWLXCK7tMLsMq3jXDCiClof6KpUQYSLGRQR_n9ruppOY6bURNVo9S1_XCK_pIoswHnFAXK9DRIFszgr2Z3l8ptyrfJ7lcq116SSbJvjLsTpHHdBsmHcPTp059yCuKo5uZgB2SpJgzo-CigOgoFuFmZSBfYQXCf-tGD0PM-iVMVRHVdYH3e8jdCq43MGPa4LaFqCKsunaJ6lhQHWREnDgFwwynUryJNB0xIVh5DPILffP1B_7VwnSt9lxY4J5LeIWu3rGWofEPgPW1wn9qHbf6LUQVaO2bziLXCzAYgeh9EFKavrmD2rbfGEOF5-1Tv5LVsV5KyAvlhIXFyf_AK_S_ILaPH1G5qSU1ZcXEQzRt4X2UUUsuIPx0fQ2klLqAKXc92nBxr1X1VildkMFhQLY3AlqbIsrqL8WS_Ner83q3eMrb-BZsuwYnO4DN60BIxNuhuWgcH9LwOAC0zi6QIG4WrrOuC6o7V1XDD4TjOr_r19QZhmlcTnLgsCGhKubt6B44Euw2owVquBiWGHQjsG2Xe8k9zBf_U6_Fe_O1rhbfJfw3A89rr3R1xc9xV6j3Vn2en331wiyrMvbmg1wlmxSqYduAHf73IGto7KJfTe1G5w122Td7uoz_aNOYM_rnvjxkIDeBGxyw2-dr8xsxVXKLEIdaJTYWAPjoEySsbxJpBfs3J90JZ4IFrXlvLCuiF7puFFUCHhDGxuMVNW_QWt2FwiK67J82K2jC5YOSFrNSq6UDV8PGBbtIjRjdPEYF6rWUzLMppHLFTr0XsoLUldTmD1YIXsa2RUp6tqmRWqO1ww8DkvaLPnqUPeoDG8I1ufTomnnV6JQdP2SjztNfDPE3W6CCYfdTgOVN3v5Xh264I0aEpyaDtiOfJQRFbm4AEDrsF2LBAp7aGR-n_OEzXDZV2jte2OLz8MXmTVda7Y1mCpR8oJm_R-ln6CnOj4tMNcIvW5rUmy71wnQji4XYQQKtibzJBr46fTDA0FSvwEnoKt-Mw7E3rno4s0sCWz1RKshLUq4gfZujvOEfJhOX37augd5kIwmbyheh2NHqZX0Z3ciHGlSehV01BI1wS0pAQtOL8OVMqI2NegJW7Yl0CQydpDW02MRu2GtWn4dONNlNt2Kq43OsC_no_eo_dEK4oYWM1Ke3xrRWyMbW1aTOx56RchRAuipqw1UpL1koF1XuodIILAS4IozVd6oTvlZWTJCnZ4eEjURBBt8G2VohSLwsxC6xULL8xFg5nOYc2AKRzMI6iAOAVy8AWkfblH4_WfyZaVflgJjdLeyY8_bCDhYZMT3GuJrTuYomc6qkC46ZK_nrX3-FWUgJIQPmbP1GpCzJF8Bjt3_qf3u9j0bWRBCXJyXFxWRZYuTsCFD-k1-d9__JP8XFxE-NUeTWybF4AywrfjI0l6PC2g0VNarQqkgz1cJzld6dovXr87ffVSd633nWj7akhLjHyEa5gOvgWmSTaNQBseXDDUfyW243rE7w-GZDywnTaGIE_87-yKJnnM0NpsQK2hiNUyKr4T0OIM3DjwEqwcWn9cMOhcXJ_8HM2rJSmrFmivs5I8TxcsZuUB-Xj6fB20ep7r4Ia0QYZZxRhgYPo6gGKhDbTboKPg1TbN96C_qbmOXDAGDmSbtO3ztT0lT3o4w7bxvqkzz99ao23zbRU_dscHrtM_GAwwfqxNvlotqjSQdhuw_ant48JTBTTw-uePv5G3736Vv9C2lyxTbuTSWWYJy9JYR_YFa9tiSeiBXCdsQZGKW-iCXCdiylXSWatuONjQiK2S2XASIOVX3obfQwyjazPp9Pc_g1P5kl17ce2VmLBt8QRxU6LIAjqr0PvG2GGtY75ItOV4eNuId_JFRmMdNQ2LLMejgkc6qG7HoA72H1R3gJ_uQZWg7TxOm4k3HBSMXFzXZ57az-tq97UzvSmCausIapXld92t8hnizwfzoZ4JStOEDS1ZTgtaacS0fXdqO6XOSfT57teNmt45fDW4X-Xc4dQf0dugOIHz3eecb-PcfbSce4-Wc__Rct5_tJwPHi3nw0fL-ejRcj7-_jl3t6xE9vfPui2vps2zrOo6etB32GpCGsf_X87SMZklumLhHh6hM4LPTLvRXCIeKMFbS4aByn7gB77yChvU5pigh8V9M_AoJW_oQLfptw3NfTnQW3VwC1AbFLHOQjOjCJ77pE6yMoXqyD3AUIcIDW6DV--eePS7QXsDuDg_1ircGd2HmtjOXDA-Y33M2mS8O59PaP-NZoCf9rZJH1rbdsyA3F33NmDVFKo700WrWX4t0qEwD4vLAQ29UKXkf_6boPlcIseULAs2f3aTUeydqKPD4yN6ckiexzHhLZWkYLB1u2Dhoc6Xa7Ogw5AYHsPorKDAJel3nUSYLaL0pj328GbrvcFer9tpdsHS7Za67zzEnn1PM62Ok3Btm4KgASZcIiRZwXRkEnj6219f_UrevPvwSv7mhEauhDwJUtDzx1xcfeIoiSrzZBR3wPh4ml1JEyUZqkA9mIo6KgrVxZjnxVl6fBSzSNPsB1NBRE6G53LsqkDk5QXlEgxaUIoEv1LFGETI5mUUErCT5HV0zsjZMioJpj38GznFOiSqJipgt71BmfYqUj3QT6AzNs2y897TiIdcXDFf7zKq-MSNJq4QepHHqxJ_e_IUPUrPWYihJOkLopAS3CBhFQVBSx6yc2WGLUvpNGahTroFHkVcIoZUref6Bw5TligtGeEkTRJ1RxmNiwyn2Dq1JGKlVFwi8FCY_PqSf_1cIkLnUal7d7B3TKWhC0l5RheY7fJFrE5rkmCbGFxcoSqs8YZ8OiC_qbyTNXpoGOHRIexNNCBDg2ZTvwIek8wZ1trUXDCZy9SSs79FzhtcMN4-LntDLz2DBsdrYH5cIm8UmHaLtg1k-3kbxHZf61wwYp5znhXVPIujLMhF4n8QAnEUl-aqPjbpcHLr82QeGJvrM6SaiucuFywGAUOTpZpCPqxnNJr5D69ePz979ZK8__DuP169ODtdb1hV22ZjUMHWqTfbrM0tixsddVYkmsZ8rnDhaexSo9BqqKRcMGeNyJAMWngv4CVnWEgmaojbdTquGAhDU6fQ75KLX66iSoU-t-biD5q5-GlWdd4v4Fl1zQNRNCxC6WnL7fqCZnRcJ4xsIzfugeGxFTxTxopOaPpNaKT1uC9k3N2QgUovYnwvBXkpCL4ePrQo91GdVSnxvFwngLzdXDDy6-n1GuzbA8MzUuigl9CBzbCJzSzOVuF9guPvBs7YXDBHtk1kGul-CO18FWhXgPa-AzScdKZldKAlvZnW-mR6hHqRGjXITJ9RY4rpVqIO-AHOVvr78zFxAY5w_8DQw_lcIi6vGL1G6VwiZnhVSOQm6LGHBfdvsE4SqVwwpcqN21pVuAdG1gNXEcDY3DYYiWPo9YvnW3YFur5aVXWaAk-mZjQJYCNQ0IYWmogpHR9vpW6uIa-ucoangzOmDhS3VetQdccRXCd3plG8F3u592W-2y-2u1wwhoocfVWo9O1HnFwwCS3OrezbAubuBRjU_bU-H_7KypXJaw3fDCtvL6zwLkEYgskq71ww1m3vn5bWxbfESr45AgU2jae8msk3K5YI2xmZjY5f19geZFEUawYVHQ4Gshe-7QfTaHGPOjhW2PJE59LKbry2rLaO-6G5JoIRzIJcIvLqw4d3H5TrogkTFkarpE7Jg1WPB4NyQJkk9Jos6QUj4OunJIG1KyRZQUIWM9jsHZI_M1KuCkaqjMyWbHaOAaWClDmLQZzFoeJWd9bKxvZVNnaagaari0fokR0vvZO3WbWEVsgcQ5bHR1BynJ-cZkVxfUCmq4qk8nlCK-g8lH2LTG6MgJaH5H3MYP9GKtgV0QWNUgKewpLgyJAwms8ZRvvJObu-zIqwPDw-yk-UopRRyNQFoXbCZ-O53Dk3no_r53zWJiyZsqK95e9vpAowRJu3aHFoa46k-9G4NIWBujUKDGvwPWG7Ob8mVkNiXsAy-L_MMh7gKWbrYhoCTKe5slUNEqMjjAtX6xQomfD7cMaVOg7FPRhHRf04S9I9FI5hkNJEWUrtXDBuJGy6ZXLVuqnV2oncrU17hzYb3utuzXo7NNv0b3dp94sYmcuZZeZ2q1kJbBqjbtXGVMV03BZFXmThalZZ4Dtaaj5cMO1YGW3oR3jKFppdqx3Y8k0K-XBTr95mulVaNQJOmLSGmlQVwFOUGR497ja4bcNDZgL_fsRrfeSFQayWt2YLyyqJxZR1m9nzq5RnzHOp67T0ZtL6avNjnkmP-c4bM91LlvNQ2Yl-uHTMLHjMojv5-Pblqw_kxbu3p2cfPr44--u7t2AlHU7s64b0reIe2M6ECZMpl1wnUiEal2DkYSwZ2MvTCr5Xq5SFf4CmfJ0o37hl4LfhuemKvXvfF6fsI1wwlbev7mo1D5r43THxGrC9TppcXGmYbpMSsFu2SBO4WVmCr1wi3hU8HPLD2PD6848_5DTEEZsQ-yne-ygWUSq-f_nxh0M5nAfksB5bqMMTM0Uy6IT8sU4X_aOZAtpsQtUS74oY2PkVPDfSOKGsL8oa6ZsT4vJSkzHxXXplE-KMOAVv_VK2lWKoPpYcrLMumHD760x4gjEO64T8NBqNNrDkrLG0tXP8HG6auYi8VIcJodMSTFDFeF9zaKJv_wt8XCfwB5xQ86d1jvahzpydEP4V7dN__skCulwndcFvokDVTLK_365eeatq2W1q7VkFRxdfDDLjxu3zmmr4YjTDqMxjCqoapXywp-DOnmN1fWM6nwd4x6g23xiLa_g-bouIx2PU9dc2tWNQl_FqoVbODTS4QdC9orOsG1wizaMqGTvU9A0GcBlZq6j3D7Ka4sQxA2eW6bZxbx_dwyYYyOoZFJM33GssG0GhLZBgv0Ydc9fUxIXnw0CpVTuu_OUzSMjdU4MP1eZfsLxUjm2btMmHbdZpCCmqaD5syYf2iVExomTBrQXqTH1xuM9fn1ct5fHiSOS189erG-8u6Os3S8wKkUxgvKFcMAdBN24oxn49jEbbe0Bl0j00EN7chzfob-zD75ICr9jibTy9Y-UupA6g1hvNOoCqNpfyFrK6uGEsT8aL7OTTT-sPdVU0iPw2Wes6nfEUl7qyokXVevl6i4SljTYclczSweJ4TYBAJo7UKUhRguNr1vLwjeWM7-eCkuf8TDlijr43LRJrdHmNk9zhlK3mGmu9qoYXoKKUgy0KcNLyt2GE4A-pq5pBlteVvvwfk9gzgA';
					$theme_options['infostack']	= 'eNrlXFzpjtw4kv7fQL8DXCcbixljS1U68na5dj22e3oWvuAqT29j0RCYKWamXFy6ICnrGMPAvMM8xb7GPso-yUbwEqVMqTLrsF1Y50xXJhUkgx-DwYhgUHTquoPp52I6mfaK8zCZp1Ga954W09G09xMLnJnbx1_DaS-i1-m6xB_9ae8yDBh-dcbT3mIdRT4W-CxiMUvKoveUTp3p53Bqi6orRgMGrX6BCtDuMkpnNPJndH6-zNN1EiD9CJkYTHthTJe8aXvak3zwojAwCqHNnGWMlkYZcJKlRViGaWKUOvCXliWdr5Az4wEMogj_bvYEnddGvxjjR3ANHYZJwvLvn2n-jzMNMxqlCHwYL83Gx1U5sOjP10WZxiaBC1PEYLAwR4sU-6fI0Wc-ggWNw-ha9vaBRuyS8l-ON-0hNuvMqkhcXKhwRldpTA_IX6DFC_hb0KSwCuh8IRu5oHlIxShHiNByHVE-HAdGW7Kr0ipzqLNIc5NJGBzyZik4gGeHS6rjwPDChFkrFi5XpXwmpBhbjFhZstwqMjoPE44LVHC2QTkZ4UchQqPIQlaFfPNGxZz1BVwncoaXabqMmBAam3NybpmtBmxB11GpXCdCP7eMkUOTP9m2zYmGNaJVesE0g7Y98uZzTgW8rxwf1xkMSs_aZGPSkKc38BQmIBeCuH3igLXnMC3RAfmFRResDOc3TB20MpAc7zltfbt92vpe57S526bNGeGne2YQLvdxwuUNOuCyHw4u75HC1SFdEsoHgav_OOFyO6TLe0DpGjxSuDqky31A6Ro-TricDulyH0i6XFxhfn47rEa3FK3J7RQX9OgeDu4gXFzFenYzYLsYf3uDdTfzr3MtjjoBc7YDNvTwc6N4zeEJWIWPCy1neL_G8riPn26sHO43Lln5PWotwGidZSyf04K1YTbuwMzbH7NdFiTUna3LMk00ZsOvh9keXCLWPfL28QGjMmrgl2GJpV91hHfdy1oHhjVmNPeLVXrZezqbOpJnLLRMl7_hE0oSf7b0tazAqAKany9zdq2cPUHTHYuYoKVQltn06GgRXkFjy-vDcgVYx1ClPJynsS63AlrSo8vMkrrsaJ1hiKA4Aj5ZcTQ8cm1ndGRPjrI0Tz-xeWnZg8NP2XIz1oHa1B3uGO7A0c6hO5YT8WfX4AdfSdITNleVCwKXL2f0T45nH3jDA9cdHdiHo_4Tvbtx4HCeK3ih9HIF4-QNuDUSHhrxa4s2CDz4xxkdSdoVTYKI5X44x2FRYPQzp43CWU5ztQMg9OFCzOBEP-TLml6yXCKNmfL3F5QsqEXzPL20gvQyqeJcMKIKah_oqlBBhIs5FBH-X2u2ns1cIqbERNVo9C1_XCK_pAwtwHnNAXK9LSPy51FasDuPq18f1zq711G59saoJNvmvIvhdM67INky7x4duQuuQVxc1ZzczIBsHVwnfhUfBRSH_lA3CyupBH2IC3-WM3qepWGi4qiOK7SPO2kjtKr4nEGP-wKqFr9MsxmqZ6lhgDVR0qVAkCuDastgncAJpD010rQdq6bfIGo0qZelfUDgf-5gXDB_D93BEyUDsnLEFiVvgTMNMB4H4QUpyuuIPasU8JQ4XnbVO_ktXefkLIe-WEDcPvkFfhfkFxDd6zc0IacsvwjnjLzP04swYPkfjo-gtZPGoHLcw3WfHojRf5WxVaRz2EUsDLwVpEzTqAyzZ70k7f1er94xof0tNC1zic3h3tectmZIni9dTXiD8h_ev_IHYGDpzpYwC1et2t91xxvaH_hOUqv63b4NzNJSAnSXbVww1QeXN-_A8Q7cAewBE7UHmBh2SLRjkH3H_uMOVqvXYbX2u2MU3jarNQgmE6_bK-LCr9B7rP5kp7V_i9jOvrih2gjm-TqedeAGfL_LGCg7KjfOexO74V2dJe92sZ52d5zBP9e90Z3QXDBehOxyi4U9qK1sxZWH8U1bmRIG9mAOKKVkHGoC-TUrNlwnbYXHoFVtOV7YOGTPNLjwSyScg87N50qrv6AlW6b5NXmez1fhBSumZKNGSZeqRh-P1ZYNYjTeNDGo13Ie0aIIFyEL1Ib0HkoLUpUT2D1YLvsaG9XpulxcpbnqDlwwfM4Lmux56mi3DqQjRWegH5u7WtPsMki2mttq1eBhXCLoehTeyFeVvpfT2NadaKgtH_45tB2xD3ke9l9kYPACoH47CAgRb4FbTdV_nFwnamnLukZr7XYuP_tdpuV1ptjWYKlHyvya9n6WBoJcXOH4tEMVDbiSidPvXCcgOLxdQBAq2Nv0j2vjp1P_jARK_MCdwlL4zDsTctdH22hoS2bLFagHa51HD-KpO84R8mE5A_tq5B1mYmAyV0P1Oh4_TK-iO-l3caGJ6ZVfD2CPlZQUIAXn177KEBFuDKrgmmLxBZmsPbLVwqjVbtcyk22UbT6K640P8P9eH81G74kWFDGxmpXm_FaCWJvbSrWY2PPSL2IQDYjqY62QkqwXDNTySjt8CAIv8cMkW-sd7pSXkRXL2eHhIVELQbTBHSrJa5gsYFOApcr7GxkF_lwiBEoEyJezLrAcSLeMbyPPZJNKMKyYhknv5McftpDw8MgJulfCRQcd9ExHDwjXWfLXs6YvX4YxSAfhk_WsXCe9KGJO4TPw0Pm_3u_Cz9vKghrIyXFR5mmyPAGjPaDX5H__8U_ycx7iV3s8tW1eXDBSCN-OjyTp8SyHRk9puc6RDtxMcrrWtV-8fnf66qXuWruaqPQqSAuMcAQbmA6_BaZxOgtBDB5cMNR_JbbjeqQ_GI7IZGg7TQxhPNG_sysaZxFDNbMFtZoglqsw_05Ai1Iw3MA8sDJo_QGgc_vk53BRrkhRNkB7nRbkebJkESsOyMfT55ugVQtcXMczpPIx9CnG-nzTyAEUc62Z3RodBTu2rreHg23NdYWaRpukDcW7YVwiedK0GTW19k2def3WGk1lb6s4sTs5cJ3BwXCIcWKt69U2USa-VNiA7U9NoxaeKqCB1z9__I28ffer_IVKvWCpsh9XziqNWZpEOoIvWGsLH6HNHbMlRSoLDcucXCdcXMrt0dmoXgWW0PWyVdIaLgKk_MqO9z1ELbrcR2ew_1mbyovs8r61OWLC1tIKeiOKzKfzEs1uDBdWMtYX0TuOh9dGvJMRMp7oQGmQpxkeCTzSSXU7JnW4_6S6Q_x0T6oEbed52k68xTMdu26fecqD19XuyyW9KWZq65hpmWZ3dVO5bPcXw8VIrwQlaUKHFiyjOS01Ylq_O5WeUuch-hz368ZJ7xywGt6vcO5wuo_obREc3_nuc8vbOHcfLefeo-W8_2g5HzxazoePlvPRo-V8_Gg5n3z_nLstO5H9_bNuyytoizQtG1FA4KXyjPRdtYqQRtH_l9NzTFoJr1iwh0XojOEz12a0iAdK8DaSXqBy3-_7fWUV1qjNOUELi9tmYFFK3tCAbtK3Tc19GdCtMtgC1BZBrLLNzCiC5z6pkqnMQXVkG2CoQ4QG2-DV3hMPe9dob1wwF9fHRoU7o_tQC9sZwmeiD1brjHfn7Qnpv1EN8PPdJulDS9uOmY67y94WrOqD6s5t0WKWXYsMKEy94uOAhl6oUvI__01QfZFjSlY5Wzy7SSn2TtSZ4fERPTkkz6OI8JYKkjNw3S5YcKjz4pos6DAkhscwOisocEv6XVwnC6bLMLnJxx7drL236OtNPc0uWNKuqQfOQ_jse6ppdY6Ee9sMBupj6kGc5kxHJoGnv_311a_kzbsPr-RvTmhkR4iEXDB9kZQ_5uIThXFYmkei6AHj41l6JVWUZKgE8WAq6qgoVBcTngpn6flRzFwiTb0fTB4Q18w8l2NX-lwiFc8vVqDQ_ELk9BUqxiBCNi_DgICeJK_Dc0bOVmFBMNHh38gp1iFhOVUBu_YGZXqrSO5AO4HO2SxNz3tPQx5yxRS9y7DkCzecumLQyyxaF_jbk8fnYXLOAgwlSVsQBynB9WNWUhhowUN2rsykZQmdRSzQybXAo0i9kKL1XFz_wGlKYyUlY1xcpHGs7lwio3KR4RRbXCeThKyQQgQWCpNfX_KvX0ToPCx07w72jskzdCkpz-gS81u-iN1pYyTYJgZXqAprvCGfDshvKtNkgx4aRnh0CHsbDYyhRrOtXwGPSeaMKmmqgczH1BjnoGWcN1ww3D4ve0MvLYMaxxtgflwibxSYdoO2CWTzeRPEZl-bXDBiPnOW5uVcIo3C1M9Egr8fXDBxGBXmrj4x6XBx64NkHhhb6DOkiornKOcsggEGJksVhXxYrWhU8x9evX5-9uolef_h3X-8enF2utmwqtamY1DANqm366ztLYubG1UeJKrGbKFw4enqUqJQa6hsXDBng8gYGbTwXsBLzrCQTNUUN-t0XFwlEIqmSpXfJee-WIelCn225twP6zn3SVp23iPgeXT1A1FULELoacPs-oJqdFwnjGwjG-6B4bEVPDPG8k5oBnVopPa4L2Tc3ZCBSi9cInz_BHkpCL4ePjQv9hGddSHxvFwngLzdXDDqV8vrNei3B4ZnrNBJzzuxGdWxmUfpOrhPcPq7gTMxwJFtE5k4uh9CO1_52RWgve_6jKadaRkdaElrprE_mRah3qTGNTLTZtSYYp6VqAN2gNNKf382Jm7AIfoPDC2cL-K-itFrmCwjhleCRG6CnnvYcP8G-ySRAlCopLjWqsI8MLIeuIhcMMam24D-SCSPmF31vMUr0PXVrqrTFHj6NKOxD45ATmtSaFwipmR80kpd30NeXWUMTwfnTB0otlXrEHXHEVwnd6ZSvBd9ufelvdtvtrtcMIaCHH5VqPQtR1xcXDAxzc-t9NsC5u4FGNT9tTof_srClcqLDN8MK28vrPD2QBCAyiruXDDWbe-ZFtbFt8RKviECB2wqT3kBkzsrlgjbGZmNTr-q0R5kURQbChUNDgZjz_t235-Fy3uUwYnClmc4F1Z64_Vk5Truh-bGEIxgFhSRVx8-vPugTBdNGLMgXFzHVUoe7Ho8GJQByiSm12RFLxgBWz8hMexdAUlzErCIgbN3SP7MSLHOGSlTMl-x-TkGlHJSZCyC4SwPFbe6s0Yadl-lYVwnKUi6umqEFtnxyjt5m5YraIUsMGR5fAQlx9nJaZrn1wdkti5JXCKfx7SEzgPZt0jhxghocUjeRwz8N1KCV0SXNEwIWAorgjNDgnCxYBjtXCfn7PoyzYPi8PgoO1GCUoQBU1eCmgmftefSc649n1TP-aqNWTxjedPlH2yl8jFEmzVocWorjqT5UbsmhYG6DQoMa3CfsNlcXL9cIlZTYl65Mvi_TFMe4Mnnm8M0BjCbZUpX1UiMjjAuXFxuUuDIhN2HK67QcShuwTgq6sdZkuahMAz9hMZKU2oDcCth3SyTu9ZNrVZG5G5t2ju0WbNed2vW26HZun27S7tfxMxcXM4tM7dbrUpg05h1q1KmKqbjNiiyPA3W89IC29FS6wFoXCdKaUM_wlK2UO1azcBW36SQD7f16m2nW1wnZS3ghElrKEllDjyFqWHRo7fBdRseMhP4-xEv8pEXBrHa3uotrMo4EkvWrWfPrxOeMc9HXaWl15PW19sf80x6zHfemulesIyHyk70w5VjZsFjFt3Jx7cvX30gL969PT378PHF2V_fvQUt6XDivm5I3yPuge6MmVCZcntcIiWicQlKHuaSgb48LeF7uU5Y8Adoqq8T5Wu3DPpNeG66VO_e940p-whA5e2rS1r1gyZ-aUy87muvkyZXKqbbpATsli1SB25eFGCriHcCj0b8MDa4_vzjDxkNcMamxH6K9z7yZZiI719-_OFQTucBOazmFurwxEyRDDolf6zSRf9opoDWm1C1xOshhnZ2Bc-NNE4oG4iyWvrmlLi81GRMfJdW2ZQ4Y07BW7-UbSUYqo8kB5usCybcwSYTnmCMwzolP43H4y0sORsstXaOn8NtKxeRl-IwJXRWgAoqGe9rAU0M7H-B7wT-gRFq_rTOUT9UmbNTwr-ifvrPP1lA96Qq-E0UqJpx-vfb1StuVS29Ta09q-Ds4rtA5lxcuX3eEI2-mM0gLLKIgqiGCZ_sGZiz51hd35HOFj7eMarUN8biaraP2yDi8Rh177VJ7RjURbReqp1zCw06CLpXNJZ1Q6R-VCVjh5q-xlwwbiMbFbX_IKspThwzcGaZZhu39tE8rIOBrJ5BMXnDrcaiFhRqgQT7NeqYXlMdF54PA6VWZbjy980gITdPDT5Um3_B8kIZtk3SOh-2Wac2SFFF82FLPrRNjIIRxkuuLVBmqhvDA_6avHIljxfHXCKvnb9G3bhkP9DvkpjnXCKZwHhcJwFOgm7cEIz9ehiP23tAYdI91BDe3oc3HGzto981Crxbi7fxtMfKTUgdQK0czSqAqpxLef1YXdwwtlwn44V18umnzYe6KipEfpuscZ3OeIpbXVHSvGy8ZL1BwpJaG45KZulgcbIxXDBfJo5UKUhhjPNr1vLwzeSM-3N-wXN-ZhwxR1-YFok1urzCSXo4RaO52l6vquEFqDDhYIsCXFy0_P0XAdhD6qqmn2ZVpS__B6ZNLpM';
					
					
					if ( !function_exists( 'tm_cs_decode_string' ) ) {
						function tm_cs_decode_string( $string ) {
							
							// decode the encrypted theme opitons
							$options = unserialize( gzuncompress( stripslashes( call_user_func( 'base'. '64' .'_decode', rtrim( strtr( $string, '-_', '+/' ), '=' ) ) ) ) );
							
							// changing image path with client website url so image will be fetched from client server directly
							$demo_domains = array(
								'http://fixology.thememount.com/fixology-data/',
								'http://fixology.thememount.com/fixology-overlay/',
								'http://fixology.thememount.com/fixology-infostack/',
								'http://fixology.thememount.com/',
							);
							
							// getting current site URL
							$current_url = get_site_url() . '/';
							
							
							// Getting layout type
							$layout_type = 'default';
							if( isset($_POST['layout_type']) && !empty($_POST['layout_type']) ){
								$layout_type = strtolower($_POST['layout_type']);
								$layout_type = str_replace(' ','-',$layout_type);
								$layout_type = str_replace(' ','-',$layout_type);
								$layout_type = str_replace(' ','-',$layout_type);
								$layout_type = str_replace(' ','-',$layout_type);
							}
							
							
							foreach( $options as $key=>$val ){
					
								switch( $key ){
									case 'logoimg':
										$logo_img_file = ( !empty($layout_type) && $layout_type=='overlay' ) ? 'logo-white.png' : 'logo.png' ;
										$val_val       = get_template_directory_uri() . '/images/'.$logo_img_file;
										$options[$key]['thumb-url'] = $val_val;  // update value
										$options[$key]['full-url'] = $val_val;  // update value
										break;
										
									case 'logoimg_sticky':
										if( !empty($layout_type) && $layout_type=='overlay' ){
											$val_val = get_template_directory_uri() . '/images/logo.png';
											$options[$key]['thumb-url'] = $val_val;  // update value
											$options[$key]['full-url'] = $val_val;  // update value
										}
										break;
									
									case 'topbar_left_text':
										if(( !empty($layout_type) && ( $layout_type=='overlay' || $layout_type=='infostack' ) )){
											$options[$key] = '<ul class="top-contact"><li><i class="fa fa-phone"></i>(123) 456-7890</li><li><i class="ti-email"></i><a href="mailto:info@example.com">info@example.com</a></li><li><i class="ti-location-pin"></i>Bulls Stadium, California</li></ul>';  // update value
										}
										break;									
									
										
									case 'fbar_background':
										$val_val = get_template_directory_uri() . '/images/floatingbar-bg.jpg';
										$options[$key]['image'] = $val_val;  // update value
										break;
										
									case 'titlebar_background':
										$val_val = get_template_directory_uri() . '/images/titlebar-bg.jpg';
										$options[$key]['image'] = $val_val;  // update value
										break;
										
									case 'full_footer_bg_all':
										$val_val = get_template_directory_uri() . '/images/footer-bg.jpg';
										$options[$key]['image'] = $val_val;  // update value
										break;
										
									case 'login_background':
										$val_val = get_template_directory_uri() . '/images/login-bg.jpg';
										$options[$key]['image'] = $val_val;  // update value
										break;
										
									case 'uconstruction_background':
										$val_val = get_template_directory_uri() . '/images/uconstruction-bg.jpg';
										$options[$key]['image'] = $val_val;  // update value
										break;
								
								}
								
								
							}  // foreach
							
							
							
						
							return $options;
						}
					}
					
					
					
					// Update theme options according to selected layout
					if( !empty($theme_options[$layout_type]) ){
						$new_options = tm_cs_decode_string( $theme_options[$layout_type] );
						
						// Image path URL change is pending
						// we need to replace image path with correct path 
						
						update_option('fixology_theme_options', $new_options);
					}
					
					
					/**** END CodeStar theme options import ****/
					
					
					
					
					
					
					
					
					
					/**** START - Edit "Hello World" post and change *****/
					$hello_world_post = get_post(1);
					if( !empty($hello_world_post) ){
						$newDate = array(
							'ID'		=> '1',
							'post_date'	=> "2014-12-10 0:0:0" // [ Y-m-d H:i:s ]
						);
						
						wp_update_post($newDate);
					}
					/**** END - Edit "Hello World" post and change *****/
					
					
					
					
				
			        // Import custom configuration
					$content = file_get_contents( FIXOLOGY_TMDC_DIR .'one-click-demo/'.$filename );
					
					if ( false !== strpos( $content, '<wp:theme_custom>' ) ) {
						preg_match('|<wp:theme_custom>(.*?)</wp:theme_custom>|is', $content, $config);
						//var_dump($config);
						if ($config && is_array($config) && count($config) > 1){
							$config = unserialize(base64_decode($config[1]));
							//var_dump($config);
							if (is_array($config)){
								$configs = array(
										'page_for_posts',
										'show_on_front',
										'page_on_front',
										'posts_per_page',
										'sidebars_widgets',
									);
								foreach ($configs as $item){
									if (isset($config[$item])){
										if( $item=='page_for_posts' || $item=='page_on_front' ){
											$page = get_page_by_title( $config[$item] );
											if( isset($page->ID) ){
												$config[$item] = $page->ID;
											}
										}
										update_option($item, $config[$item]);
									}
								}
								if (isset($config['sidebars_widgets'])){
									$sidebars = $config['sidebars_widgets'];
									update_option('sidebars_widgets', $sidebars);
									// read config
									$sidebars_config = array();
									if (isset($config['sidebars_config'])){
										$sidebars_config = $config['sidebars_config'];
										if (is_array($sidebars_config)){
											foreach ($sidebars_config as $name => $widget){
												update_option('widget_'.$name, $widget);
											}
										}
									}
								}
								
								if ( isset($config['menu_list']) && is_array($config['menu_list']) && count($config['menu_list'])>0 ){
									foreach( $config['menu_list'] as $location=>$menu_name ){
										$locations = get_theme_mod('nav_menu_locations'); // Get all menu Locations of current theme
										
										// Get menu name by id
										$term = get_term_by('name', $menu_name, 'nav_menu');
										$menu_id = $term->term_id;
										
										$locations[$location] = $menu_id;  //$foo is term_id of menu
										set_theme_mod('nav_menu_locations', $locations); // Set menu locations
									}
								}
								
							}
						}
					}
					
					
					
					
					// Updating homepage to change the slider to overlay slider for overlay headertype only
					$overlay_slider = 'fixology-overlay-mainslider';
					if( !empty($layout_type) && $layout_type=='overlay' ){  // Getting layout type
						$frontpage_id = get_option('page_on_front');
						if( !empty($frontpage_id) ){
							$meta              = get_post_meta( $frontpage_id , '_thememount_metabox_group', true);
							$meta['revslider'] = $overlay_slider;
							update_post_meta( $frontpage_id , '_thememount_metabox_group', $meta );
						}
					}
					
					
					
					
					
					// Update term count in admin section
					tm_update_term_count();
					flush_rewrite_rules(); // flush rewrite rule
					
					$answer['answer'] = 'finished';
					$answer['reload'] = 'yes';
					die( json_encode( $answer ) );
					
				break;
				
			}
			die;
		}
		
		
		
		/**
		 * Fetch and save image
		 **/
		function grab_image($url,$saveto){
			$ch = curl_init ($url);
			curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_BINARYTRANSFER,1);
			$raw=curl_exec($ch);
			curl_close ($ch);
			if(file_exists($saveto)){
				unlink($saveto);
			}
			$fp = fopen($saveto,'x');
			fwrite($fp, $raw);
			fclose($fp);
		}



	} // END class

} // END if



if( !function_exists('tm_update_term_count') ){
function tm_update_term_count(){
	$get_taxonomies = get_taxonomies();
	foreach( $get_taxonomies as $taxonomy=>$taxonomy2 ){
		$terms = get_terms( $taxonomy, 'hide_empty=0' );
		$terms_array = array();
		foreach( $terms as $term ){
			$terms_array[] = $term->term_id;
		}
		if( !empty($terms_array) && count($terms_array)>0 ){
			$output = wp_update_term_count_now( $terms_array, $taxonomy );
		}
	}
}
}




// For AJAX callback
$thememount_fixology_one_click_demo_setup = new thememount_fixology_one_click_demo_setup;



